from django.shortcuts import render
from django.http import HttpResponse,HttpResponseRedirect
# Create your views here.
def Index(request):
    return render(request,'b2.html')

def Index2(request):
    return render(request,'Beverages.html')

def Index3(request):
    return render(request,'chaat.html')

def Index4(request):
    return render(request,'italian.html')

def Index5(request):
    return render(request,'North.html')

def Index6(request):
    return render(request,'Southindian.html')

def Index7(request):
    return render(request,'cart.html')

def Index8(request):
    return render(request,'payment.html')

