from django.urls import path
from Food import views
urlpatterns=[
    path('italian/',views.Index4,name="italian"),
    path('beverages/',views.Index2,name="Beverages"),
    path('chaat/',views.Index3,name="chaat"),
 
    path('northindian/',views.Index5,name="North"),
    path('southindian/',views.Index6,name="Southindian"),
    path('',views.Index,name="b2"),
    path('cart/',views.Index7,name="cart"),
    path('payment/',views.Index8,name="payment"),
    
]