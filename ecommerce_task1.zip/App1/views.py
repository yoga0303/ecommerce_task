from django.shortcuts import render
from django.http import HttpResponse,HttpResponseRedirect
# Create your views here.
def Index(request):
    return render(request,'index.html')

def Index2(request):
    return render(request,'home.html')

def Index3(request):
    return render(request,'http.html')

def Index4(request):
    return render(request,'real.html')