from django.urls import path
from App1 import views
urlpatterns=[
    path('index/',views.Index,name="Index"),
    path('home/',views.Index2,name="home"),
    path('http/',views.Index3,name="http"),
    path('',views.Index4,name="Index4")
]