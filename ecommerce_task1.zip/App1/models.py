from django.db import models
class accountdetails ( models.Model):
    firstname=models.CharField( max_length=50)
    lastname=models.CharField( max_length=50)
    email=models.CharField(max_length=50)
    contactno=models.IntegerField(12)
    address=models.TextField()
    
    
